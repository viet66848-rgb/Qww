package com.doubleclick;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;
import java.util.List;

public class ESPRenderer {
    
    private static final float MAX_DISTANCE = 50.0f;
    
    public static void renderESP(MatrixStack matrixStack, VertexConsumerProvider vertexConsumers, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        if (!DoubleClickMod.isEspEnabled() || client.player == null || client.world == null) {
            return;
        }
        
        List<Entity> entities = client.world.getEntities();
        Vec3d cameraPos = client.gameRenderer.getCamera().getPos();
        
        for (Entity entity : entities) {
            if (entity == client.player) continue;
            if (entity.isSpectator()) continue;
            if (entity.squaredDistanceTo(client.player) > MAX_DISTANCE * MAX_DISTANCE) continue;
            
            Color color = getEntityColor(entity);
            drawEntityBox(matrixStack, vertexConsumers, entity, cameraPos, color, tickDelta);
        }
    }
    
    private static Color getEntityColor(Entity entity) {
        if (entity instanceof PlayerEntity) {
            return Color.RED; // Player màu đỏ
        } else if (entity instanceof HostileEntity) {
            return Color.ORANGE; // Quái vật màu cam
        } else if (entity instanceof PassiveEntity) {
            return Color.GREEN; // Động vật lành màu xanh lá
        } else {
            return Color.CYAN; // Entity khác màu xanh dương
        }
    }
    
    private static void drawEntityBox(MatrixStack matrixStack, VertexConsumerProvider vertexConsumers, 
                                       Entity entity, Vec3d cameraPos, Color color, float tickDelta) {
        // Tính toán bounding box của entity
        Box box = entity.getBoundingBox();
        Vec3d entityPos = entity.getLerpedPos(tickDelta);
        
        double x = entityPos.x - cameraPos.x;
        double y = entityPos.y - cameraPos.y;
        double z = entityPos.z - cameraPos.z;
        
        double width = (box.maxX - box.minX) / 2.0;
        double height = box.maxY - box.minY;
        
        matrixStack.push();
        matrixStack.translate(x, y, z);
        
        // Vẽ outline box
        drawOutlineBox(matrixStack, vertexConsumers, -width, 0, -width, width, height, width, color);
        
        matrixStack.pop();
    }
    
    private static void drawOutlineBox(MatrixStack matrixStack, VertexConsumerProvider vertexConsumers,
                                       double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        Matrix4f matrix = matrixStack.peek().getPositionMatrix();
        var consumer = vertexConsumers.getBuffer(net.minecraft.client.render.RenderLayer.getLines());
        
        float r = color.getRed() / 255.0f;
        float g = color.getGreen() / 255.0f;
        float b = color.getBlue() / 255.0f;
        
        // 12 đường kẻ cho hình hộp
        // Mặt dưới
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        // Mặt trên
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        // Các cạnh dọc
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x2, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x2, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
        consumer.vertex(matrix, (float)x1, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
    }
}