package com.doubleclick;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class DoubleClickMod implements ClientModInitializer {
    public static final String MOD_ID = "doubleclickmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static boolean doubleClickEnabled = true;
    private static boolean lagReducerEnabled = true;
    private static boolean espEnabled = false;
    private static int doubleClickDelayMs = 30;
    
    private static KeyBinding toggleDoubleClickKey;
    private static KeyBinding toggleLagReducerKey;
    private static KeyBinding toggleEspKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[DoubleClickMod] Khoi tao thanh cong!");
        LOGGER.info("[DoubleClickMod] Phim R: Double Click | Phim Y: Lag Reducer | Phim H: ESP");
        
        // Tối ưu settings mặc định để giảm lag
        optimizeGameSettings();
        
        // Đăng ký phím R để bật/tắt Double Click
        toggleDoubleClickKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.doubleclick.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "category.doubleclick"
        ));
        
        // Đăng ký phím Y để bật/tắt Lag Reducer
        toggleLagReducerKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.lagreducer.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_Y,
            "category.doubleclick"
        ));
        
        // Đăng ký phím H để bật/tắt ESP
        toggleEspKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.esp.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            "category.doubleclick"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.currentScreen == null) {
                if (toggleDoubleClickKey.wasPressed()) {
                    doubleClickEnabled = !doubleClickEnabled;
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal(
                            doubleClickEnabled ? "§a§l[DOUBLE CLICK] BAT" : "§c§l[DOUBLE CLICK] TAT"
                        ), true);
                    }
                }
                
                if (toggleLagReducerKey.wasPressed()) {
                    lagReducerEnabled = !lagReducerEnabled;
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal(
                            lagReducerEnabled ? "§a§l[LAG REDUCER] BAT" : "§c§l[LAG REDUCER] TAT"
                        ), true);
                    }
                    applyLagReducerSettings(client);
                }
                
                if (toggleEspKey.wasPressed()) {
                    espEnabled = !espEnabled;
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal(
                            espEnabled ? "§a§l[ESP] BAT - Nhin xuyen tuong" : "§c§l[ESP] TAT"
                        ), true);
                    }
                }
            }
        });
    }
    
    private void optimizeGameSettings() {
        MinecraftClient client = MinecraftClient.getInstance();
        
        try {
            // Giảm render distance
            if (client.options.getViewDistance().getValue() > 12) {
                client.options.getViewDistance().setValue(12);
            }
            
            // Giảm simulation distance
            if (client.options.getSimulationDistance().getValue() > 10) {
                client.options.getSimulationDistance().setValue(10);
            }
            
            // Tắt VSync để giảm input lag
            client.options.enableVsync = false;
            
            // Giới hạn FPS
            if (client.options.getMaxFps().getValue() > 120) {
                client.options.getMaxFps().setValue(120);
            }
            
            // Chế độ đồ họa nhanh
            client.options.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FAST);
            
            // Tắt mây
            client.options.getCloudsMode().setValue(net.minecraft.client.option.CloudsMode.OFF);
            
            // Giảm particles
            client.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);
            
            // Tắt bóng đổ
            client.options.setAo(false);
            
            // Giảm chất lượng nước
            client.options.getSmoothLighting().setValue(net.minecraft.client.option.SmoothLighting.OFF);
            
            LOGGER.info("[DoubleClickMod] Da toi uu cai dat do hoa!");
        } catch (Exception e) {
            LOGGER.warn("[DoubleClickMod] Khong the toi uu mot so cai dat: " + e.getMessage());
        }
    }
    
    private void applyLagReducerSettings(MinecraftClient client) {
        try {
            if (lagReducerEnabled) {
                // Chế độ giảm lag tối đa
                client.options.getViewDistance().setValue(8);
                client.options.getSimulationDistance().setValue(6);
                client.options.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FAST);
                client.options.getCloudsMode().setValue(net.minecraft.client.option.CloudsMode.OFF);
                client.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);
                client.options.getMaxFps().setValue(60);
                client.options.setAo(false);
                client.options.getSmoothLighting().setValue(net.minecraft.client.option.SmoothLighting.OFF);
                client.options.getBiomeBlendRadius().setValue(1);
                client.options.getEntityDistanceScaling().setValue(0.5);
            } else {
                // Chế độ bình thường
                client.options.getViewDistance().setValue(12);
                client.options.getSimulationDistance().setValue(10);
                client.options.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FANCY);
                client.options.getCloudsMode().setValue(net.minecraft.client.option.CloudsMode.FAST);
                client.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.DECREASED);
                client.options.getMaxFps().setValue(120);
                client.options.setAo(true);
                client.options.getSmoothLighting().setValue(net.minecraft.client.option.SmoothLighting.ON);
                client.options.getBiomeBlendRadius().setValue(3);
                client.options.getEntityDistanceScaling().setValue(1.0);
            }
        } catch (Exception e) {
            LOGGER.warn("[DoubleClickMod] Loi khi ap dung Lag Reducer: " + e.getMessage());
        }
    }

    public static boolean isDoubleClickEnabled() {
        return doubleClickEnabled;
    }
    
    public static boolean isLagReducerEnabled() {
        return lagReducerEnabled;
    }
    
    public static boolean isEspEnabled() {
        return espEnabled;
    }

    public static int getDoubleClickDelayMs() {
        return doubleClickDelayMs;
    }
}