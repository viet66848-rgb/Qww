package com.doubleclick.mixin;

import com.doubleclick.DoubleClickMod;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @Shadow
    private int blockBreakingCooldown;
    
    @Shadow
    protected abstract void syncSelectedSlot();

    private long lastClickTime = 0;

    @Inject(method = "attackBlock", at = @At("HEAD"), cancellable = false)
    private void onAttackBlock(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
        if (!DoubleClickMod.isDoubleClickEnabled()) return;
        
        long now = System.currentTimeMillis();
        if (now - lastClickTime < 50) return;
        lastClickTime = now;
        
        scheduleSecondClick(() -> {
            blockBreakingCooldown = 0;
            syncSelectedSlot();
        });
    }

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = false)
    private void onAttackEntity(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (!DoubleClickMod.isDoubleClickEnabled()) return;
        
        long now = System.currentTimeMillis();
        if (now - lastClickTime < 50) return;
        lastClickTime = now;
        
        scheduleSecondClick(() -> {
            syncSelectedSlot();
        });
    }

    private void scheduleSecondClick(Runnable action) {
        int delay = DoubleClickMod.getDoubleClickDelayMs();
        new Thread(() -> {
            try {
                Thread.sleep(delay);
                action.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }
}